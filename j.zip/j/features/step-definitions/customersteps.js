const {When,Then, After, Before } =require('@cucumber/cucumber');
const {expect} = require('chai')
//const {Builder, By, Key, until} = require('selenium-webdriver');
const webdriver = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome')
const {initDriver} =require('../driver/driverUtil')



let sum=0;
let driver;

Before(function () {

    driver = initDriver()
});


After(function () {
  driver.quit();
});



When('I add {int} and {int}', function (num1, num2) {
        sum = num1+num2;

    });



Then('the result should be {int}', function (result) {
        expect(sum).equal(result);

        });

When('I visit on google', async () => {

 driver.get("https://www.google.co.uk");
    thread.sleep(5000);

});

